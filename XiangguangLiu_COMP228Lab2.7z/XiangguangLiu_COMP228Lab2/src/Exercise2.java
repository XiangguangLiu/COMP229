import javax.swing.*;

public class Exercise2 {
    private int[] array;

    public Exercise2()

    {
        array = new int[3];

        for (int i = 0; i <3 ; i++) {


            int number = (int) (Math.random() * (9 - 1)+ 1);


            array[i] = number;
        }

    }

    public int[] getArray() {

        return array;

    }

}

