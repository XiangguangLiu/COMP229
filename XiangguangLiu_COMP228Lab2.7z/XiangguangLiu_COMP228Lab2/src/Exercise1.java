import java.util.Random;
import java.util.Scanner;

public class Exercise1 {

    private final String[] questions = {

            "What is the Capital of England?",

            "What is the Sum of first 10 numbers?",

            "Which continent is called as Dark Continent?",

            "What is the highest peak in the world?",

            "What is the result of 2 + 3 * 10 / 2 = ?"

    };
    private final String[] answers={

            "London",

            "55",

            "Africa",

            "Mount Everest",

            "17"

    };

    private final String[][] options = {

            {"London","New York","Rome","Washington"},

            {"10","55","54","52"},

            {"America","Europe","Asia","Africa"},

            {"Mount Cameroon","Mount Everest","Chomo Lonzo","Vinson Massif"},

            {"16","50","17","25"}

    };


    Random randomObject;

    Scanner in;



    Exercise1()

    {

        randomObject = new Random();

        in = new Scanner(System.in);



    }


    int simulateQuestion(int qInd)

    {



        System.out.println("\n"+(qInd+1)+". "+questions[qInd]);

        int opLen = options[qInd].length;

        for(int i = 0 ; i < opLen ; i++)

        {

            System.out.println("\n"+(char)('a'+i)+". "+options[qInd][i]);

        }

        return qInd;

    }

    boolean checkAnswer(String answer,int qInd)

    {

        if(answer.length() != 1)

        {

            return false;

        }



        int opLen = options[qInd].length;

        String choosenAns="";

        boolean found = false;

        String i_thOp;

        for(int i =0; i<opLen;i++)

        {

            i_thOp = ""+(char)('a'+i);



            if(answer.equals(i_thOp))

            {

                choosenAns = options[qInd][i];

                found = true;

                break;

            }

        }



        if(!found)

        {

            return false;

        }

        else

        {



            return answers[qInd].equals(choosenAns);

        }

    }

    void inputAnswer()

    {

        int posScore = 0;

        int negScore = 0;

        for(int i = 0;i<questions.length;i++)

        {

            int qInd = simulateQuestion(i);

            System.out.print("\nEnter your option: ");

            String ans = in.nextLine();

            System.out.println("");

            if(checkAnswer(ans,qInd))

            {

                System.out.println(generateMessage(true));

                posScore++;

            }

            else

            {

                System.out.println(generateMessage(false));

                negScore++;

            }

        }

        System.out.println("\nTotal Right Answer: "+posScore);

        System.out.println("Total Wrong Answer: "+negScore);

        float percent = (float)posScore /(posScore + negScore);

        System.out.println(String.format("Percentage of Right Answers: %.2f",percent));



    }

    String generateMessage(boolean positive)

    {


        if(positive)

        {


            switch(randomObject.nextInt(4))

            {

                case 0:

                    return "Excellent!";



                case 1:

                    return "Good!";



                case 2:

                    return "Keep up the good work!";



                case 3:

                    return "Nice work!";



            }

        }

        else

        {

            //negative messages



            switch(randomObject.nextInt(4))

            {

                case 0:

                    return "No. Please try again";



                case 1:

                    return "Wrong. Try once more" ;



                case 2:

                    return "Don't give up!" ;



                case 3:

                    return "No. Keep trying..";



            }

        }

        return"";

    }


    public static void main(String[] args) {


        Exercise1 driver = new Exercise1();

        driver.inputAnswer();

    }


}