"use strict";
(function () {
  function Start() {
    console.log("Start...");
  }
  //homepage animation
  const lottiehome = document.querySelector(".lottiehome");
  lottie.loadAnimation({
    container: lottiehome,
    renderer: "svg",
    loop: true,
    autoplay: true,
  });
  window.addEventListener("load", Start);
})();
//# sourceMappingURL=app.js.map