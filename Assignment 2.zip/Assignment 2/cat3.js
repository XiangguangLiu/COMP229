"use strict";
(function () {
  function Start() {
    console.log("Start...");
  }
  window.addEventListener("load", Start);
})();
//# sourceMappingURL=app.js.map