 module.exports = {
     "AtlasDB": "mongodb+srv://Movie_pankaj:4MzXqKGBObLjKpNB@movies.81sod.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
 }